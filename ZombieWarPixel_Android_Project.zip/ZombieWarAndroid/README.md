# Zombie War Pixel — Android

Project Android native WebView untuk game zombie pixel 2D.

## Fitur
- Kontrol touchscreen landscape
- Joystick gerak dan bidik
- Serangan jarak dekat/non-senjata
- Zombie biasa dan zombie kuat
- Wave, HP, score, coin
- Upgrade damage, speed, max HP
- Pause dan game over

## Build APK
Buka folder ini di Android Studio, tunggu Gradle sync, lalu pilih:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

APK debug biasanya berada di:
app/build/outputs/apk/debug/app-debug.apk

Catatan: Gradle/Android SDK perlu tersedia di komputer saat build pertama.
