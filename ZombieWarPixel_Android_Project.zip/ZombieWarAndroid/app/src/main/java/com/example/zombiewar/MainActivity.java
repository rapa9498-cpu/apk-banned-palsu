package com.example.zombiewar;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b);
    WebView w=new WebView(this); w.setBackgroundColor(0xff101418); w.setWebViewClient(new WebViewClient());
    WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    w.setOverScrollMode(WebView.OVER_SCROLL_NEVER); setContentView(w); w.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed(){ }
}
