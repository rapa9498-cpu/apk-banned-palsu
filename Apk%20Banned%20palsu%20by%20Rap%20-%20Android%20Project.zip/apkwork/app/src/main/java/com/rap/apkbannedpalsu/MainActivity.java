package com.rap.apkbannedpalsu;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(3,7,17));
        getWindow().setNavigationBarColor(Color.rgb(3,7,17));
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(3,7,17));
        web.setWebViewClient(new WebViewClient());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
}
