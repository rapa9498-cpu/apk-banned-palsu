Apk Banned palsu by Rap

Android project wrapper for the supplied local prank/simulation webpage.
No INTERNET permission is requested; the page is loaded from app assets.

Build with Android Studio:
1. Open this folder as an existing Gradle project.
2. Let Gradle sync.
3. Build > Build APK(s).

Application ID: com.rap.apkbannedpalsu
Version: 1.0
