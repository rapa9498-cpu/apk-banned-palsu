# Zombie War Pixel

Game Android pixel 2D survival berbasis WebView + HTML/CSS/JavaScript.

## Mekanik
- Kontrol joystick touchscreen
- Serangan jarak dekat/non-senjata
- Wave zombie dan zombie kuat
- Boss setiap 5 wave
- HP, score, coin
- Upgrade damage, speed, dan max HP
- Shop setelah wave selesai
- Game over dan restart

## Build
Gunakan Gradle 8.7 + JDK 17, atau GitHub Actions workflow yang tersedia.
