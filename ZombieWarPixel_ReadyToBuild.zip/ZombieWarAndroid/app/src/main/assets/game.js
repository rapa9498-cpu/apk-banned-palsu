const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
let W=480,H=270,last=0,running=false,paused=false,wave=1,spawnLeft=0,spawnTimer=0,waveCleared=false;
const p={x:240,y:135,r:8,hp:100,maxHp:100,speed:1.8,damage:2,coins:0,score:0,attackCd:0,attack:0};
let zombies=[],particles=[],hitFlash=0;
const keys={x:0,y:0,ax:1,ay:0,fire:false};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rand=(a,b)=>Math.random()*(b-a)+a;
function resize(){canvas.width=480;canvas.height=270} addEventListener('resize',resize);resize();
function msg(t){const e=document.getElementById('message');e.textContent=t;clearTimeout(msg.t);msg.t=setTimeout(()=>e.textContent='',800)}
function reset(){Object.assign(p,{x:240,y:135,hp:100,maxHp:100,speed:1.8,damage:2,coins:0,score:0,attackCd:0,attack:0});zombies=[];particles=[];wave=1;waveCleared=false;startWave();running=true;paused=false;document.getElementById('shop').hidden=true;updateHud()}
function startWave(){spawnLeft=5+wave*3+(wave%5===0?1:0);spawnTimer=.4;waveCleared=false;msg('WAVE '+wave+(wave%5===0?' • BOSS!':''))}
function spawn(){
  const s=Math.floor(Math.random()*4),x=s===0?rand(0,W):s===1?W+12:s===2?rand(0,W):-12,y=s===0?-12:s===1?rand(0,H):s===2?H+12:rand(0,H);
  const boss=wave%5===0&&spawnLeft===1;
  const strong=!boss&&Math.random()<Math.min(.18+wave*.015,.38);
  const type=boss?2:(strong?1:0);
  const hp=type===2?18+wave*2:type===1?5+wave:2+Math.floor(wave/3);
  zombies.push({x,y,r:type===2?13:type===1?10:8,hp,max:hp,speed:type===2?.3:type===1?.42+.01*wave:.65+.015*wave,type,attackCd:0});
}
function attack(){
  if(p.attackCd>0)return;
  p.attackCd=.42;p.attack=.14;
  let ax=keys.ax,ay=keys.ay;if(Math.hypot(ax,ay)<.2){ax=1;ay=0}
  for(let i=zombies.length-1;i>=0;i--){
    const z=zombies[i],dx=z.x-p.x,dy=z.y-p.y,d=Math.hypot(dx,dy)||1,dot=(dx/d)*ax+(dy/d)*ay;
    if(d<48&&dot>.05){
      z.hp-=p.damage;
      for(let k=0;k<5;k++)particles.push({x:z.x,y:z.y,vx:rand(-1.2,1.2),vy:rand(-1.2,1.2),life:18});
      if(z.hp<=0){p.score+=z.type===2?100:z.type===1?30:10;p.coins+=z.type===2?10:z.type===1?3:1;zombies.splice(i,1)}
    }
  }
}
function update(dt){
  if(paused)return;
  p.attackCd=Math.max(0,p.attackCd-dt);p.attack=Math.max(0,p.attack-dt);hitFlash=Math.max(0,hitFlash-dt);
  const m=Math.hypot(keys.x,keys.y);if(m>.05){p.x+=keys.x/m*p.speed*60*dt;p.y+=keys.y/m*p.speed*60*dt}
  p.x=clamp(p.x,10,W-10);p.y=clamp(p.y,10,H-10);if(keys.fire)attack();
  if(spawnLeft>0){spawnTimer-=dt;if(spawnTimer<=0){spawn();spawnLeft--;spawnTimer=Math.max(.2,1-wave*.025)}}
  else if(!zombies.length&&!waveCleared){waveCleared=true;running=false;paused=true;document.getElementById('shop').hidden=false;msg('WAVE CLEAR!')}
  for(const z of zombies){
    const dx=p.x-z.x,dy=p.y-z.y,d=Math.hypot(dx,dy)||1;z.x+=dx/d*z.speed*60*dt;z.y+=dy/d*z.speed*60*dt;
    if(d<z.r+p.r){z.attackCd-=dt;if(z.attackCd<=0){p.hp-=(z.type===2?18:z.type===1?12:8);z.attackCd=z.type===2?.55:.7;hitFlash=.12}}
  }
  for(let i=particles.length-1;i>=0;i--){const q=particles[i];q.x+=q.vx*60*dt;q.y+=q.vy*60*dt;q.life--;if(q.life<=0)particles.splice(i,1)}
  if(p.hp<=0)gameOver();updateHud();
}
function updateHud(){document.getElementById('hp').textContent=Math.max(0,Math.ceil(p.hp))+'/'+p.maxHp;document.getElementById('coins').textContent=p.coins;document.getElementById('score').textContent=p.score;document.getElementById('wave').textContent=wave;document.getElementById('ammo').textContent='MELEE';document.getElementById('weapon').textContent='FIST'}
function draw(){
  ctx.fillStyle='#182018';ctx.fillRect(0,0,W,H);ctx.fillStyle='#202a20';for(let x=0;x<W;x+=16)for(let y=0;y<H;y+=16)ctx.fillRect(x+1,y+1,14,14);
  zombies.forEach(z=>{ctx.fillStyle=z.type===2?'#8b5a2b':z.type===1?'#7b2635':'#3d9b4a';ctx.fillRect(z.x-z.r,z.y-z.r,z.r*2,z.r*2);ctx.fillStyle='#111';ctx.fillRect(z.x-5,z.y-3,3,3);ctx.fillRect(z.x+2,z.y-3,3,3);if(z.type===2){ctx.fillStyle='#f3c969';ctx.fillRect(z.x-7,z.y-8,14,2)}});
  particles.forEach(q=>{ctx.fillStyle='#b7e36b';ctx.fillRect(q.x-1,q.y-1,3,3)});
  ctx.fillStyle='#2d7dd2';ctx.fillRect(p.x-7,p.y-7,14,14);ctx.fillStyle='#8ed1ff';ctx.fillRect(p.x-4,p.y-11,8,4);
  if(p.attack>0){ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(p.x,p.y,36,Math.atan2(keys.ay,keys.ax)-.7,Math.atan2(keys.ay,keys.ax)+.7);ctx.stroke()}
  if(hitFlash>0){ctx.fillStyle='rgba(255,60,60,.18)';ctx.fillRect(0,0,W,H)}
}
function loop(t){const dt=Math.min(.033,(t-last)/1000||0);last=t;if(running)update(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);
function gameOver(){running=false;paused=true;document.getElementById('gameover').hidden=false;document.getElementById('finalScore').textContent=p.score}
document.getElementById('startBtn').onclick=()=>{document.getElementById('menu').hidden=true;document.getElementById('gameWrap').hidden=false;reset()};
document.getElementById('restartBtn').onclick=()=>{document.getElementById('gameover').hidden=true;reset()};
document.getElementById('helpBtn').onclick=()=>document.getElementById('help').hidden=!document.getElementById('help').hidden;
document.getElementById('pause').onclick=()=>{if(!running)return;paused=!paused;msg(paused?'PAUSE':'RESUME')};
document.getElementById('fire').onpointerdown=e=>{e.preventDefault();keys.fire=true;attack()};document.getElementById('fire').onpointerup=()=>keys.fire=false;document.getElementById('fire').onpointercancel=()=>keys.fire=false;
document.getElementById('reload').onclick=()=>msg('Serangan siap!');
document.getElementById('weaponBtn').onclick=()=>msg('Mode: SERANGAN TANGAN');
function joy(id,kind){const el=document.getElementById(id),st=el.querySelector('.stick');let active=false,cx,cy;el.addEventListener('pointerdown',e=>{active=true;el.setPointerCapture(e.pointerId);const r=el.getBoundingClientRect();cx=r.left+r.width/2;cy=r.top+r.height/2;move(e)});el.addEventListener('pointermove',e=>{if(active)move(e)});el.addEventListener('pointerup',end);el.addEventListener('pointercancel',end);function move(e){let dx=e.clientX-cx,dy=e.clientY-cy,m=45,l=Math.hypot(dx,dy)||1;if(l>m){dx=dx/l*m;dy=dy/l*m}st.style.transform=`translate(${dx}px,${dy}px)`;if(kind==='move'){keys.x=dx/m;keys.y=dy/m}else{keys.ax=dx/m;keys.ay=dy/m}}function end(){active=false;st.style.transform='';if(kind==='move')keys.x=keys.y=0;else keys.ax=1,keys.ay=0}}
joy('joyMove','move');joy('joyAim','aim');
document.querySelectorAll('[data-up]').forEach(b=>b.onclick=()=>{const u=b.dataset.up,cost=u==='maxhp'?30:20;if(p.coins<cost)return msg('COIN KURANG');p.coins-=cost;if(u==='damage')p.damage++;if(u==='speed')p.speed+=.2;if(u==='maxhp'){p.maxHp+=20;p.hp+=20}updateHud();msg('UPGRADE BERHASIL')});
document.getElementById('continueBtn').onclick=()=>{document.getElementById('shop').hidden=true;wave++;paused=false;running=true;startWave()};
addEventListener('keydown',e=>{if(e.key==='w')keys.y=-1;if(e.key==='s')keys.y=1;if(e.key==='a')keys.x=-1;if(e.key==='d')keys.x=1;if(e.code==='Space')keys.fire=true});
addEventListener('keyup',e=>{if(e.key==='w'||e.key==='s')keys.y=0;if(e.key==='a'||e.key==='d')keys.x=0;if(e.code==='Space')keys.fire=false});
